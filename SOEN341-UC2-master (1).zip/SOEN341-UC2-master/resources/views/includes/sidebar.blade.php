<!-- sidebar nav -->
<nav id="sidebar-nav">
    <ul class="nav nav-pills nav-stacked ml-3">

        </br>
        @yield('related')
    </ul>
</nav>

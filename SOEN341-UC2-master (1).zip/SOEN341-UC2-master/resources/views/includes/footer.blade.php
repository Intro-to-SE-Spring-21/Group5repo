<footer class="footer-bottom">
    <p> &#169;All rights reserved by StackUnderflow </p>
</footer>